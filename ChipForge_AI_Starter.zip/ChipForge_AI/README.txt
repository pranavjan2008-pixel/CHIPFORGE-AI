# ChipForge AI — starter website

This is a free, beginner-friendly static website starter. It uses plain HTML, CSS, and JavaScript in one file.

## Open it
- Open `index.html` in a browser, or
- Upload `index.html` to a static hosting service to publish it.

## Important
This is the website's front-end prototype. PCB routing, VLSI simulation, AI responses, accounts, and cloud saving are not implemented yet; those require engineering backends and specialist design/simulation tools.

## Customize
Search in `index.html` for `ChipForge AI` and edit the text. Colors are at the top of the CSS under `:root`.
